timed.concurrent.sensitivity <-
function(res,obsSens,outName="Prot[0-9]+",nboot=0,plot=FALSE){
timedSC<-data.frame(time=0,param='',value=0,pval=0)[FALSE,]
for(i in unique(obsSens$time)){
cs0<-concurrent.sensitivity(res,obsSens,time=i,outName,nboot)
timedSC<-rbind(timedSC,data.frame(time=i,param=rownames(cs0$prcc),value=cs0$prcc$sc,pval=cs0$prcc$pval))
cat(paste(i,'\n'))

}
return(timedSC);
}
